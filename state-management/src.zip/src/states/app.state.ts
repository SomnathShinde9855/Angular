export interface CounterState {
  count: number;
}

export const initialState: CounterState = {
  count: 0,
};
